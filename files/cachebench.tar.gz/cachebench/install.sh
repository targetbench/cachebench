build_cachebench() {
    set -e
    ARCH=`uname -i`
    if [ $ARCH = "x86_32" -o $ARCH = "x86_64" ]; then
        make CFLAGS="-msse4" -s
    elif [ $ARCH = "aarch32" ]; then
        make CFLAGS="-mfloat-abi=hard -mfpu=vfpv4 -mcpu=cortex-a15" -s
    elif [ $ARCH = "aarch64" ]; then
        make -s
    else
        make -s
    fi
}

build_cachebench

